/* Liquid chrome over Nova's mark on the startup screen. Inputs from Nova:
   tex (the logo), t (seconds), px (one texel). */
precision mediump float;
varying vec2 v;
uniform sampler2D tex;
uniform float t;
uniform float px;
float m(vec2 p) { return texture2D(tex, clamp(p, 0., 1.)).a; }
void main() {
  vec2 g = (vec2(v.x, 1. - v.y) * 128. - 26.) / 76.;
  float inside = step(0., g.x) * step(g.x, 1.) * step(0., g.y) * step(g.y, 1.);
  float a = m(g) * inside;
  if (a < .01) { gl_FragColor = vec4(0.); return; }
  float d = px * 4.;
  float dx = m(g + vec2(d, 0.)) - m(g - vec2(d, 0.));
  float dy = m(g + vec2(0., d)) - m(g - vec2(0., d));
  vec3 n = normalize(vec3(-dx, dy, .55));
  float flow = g.y * 4.2 + n.y * 2.4 + n.x * 1.6 - t * 1.9 + sin(g.x * 6. + t * 1.3) * .45;
  float band = sin(flow) * .5 + .5;
  vec3 sky = vec3(.97, 1., 1.);
  vec3 sea = vec3(.36, .78, .98);
  vec3 col = mix(sea, sky, smoothstep(.25, .75, band));
  col += pow(max(0., dot(n, normalize(vec3(-.4, .6, .7)))), 24.) * .9;
  col = mix(col, vec3(.6, .95, .85), smoothstep(.7, 1., g.y) * .35);
  gl_FragColor = vec4(col * a, a);
}