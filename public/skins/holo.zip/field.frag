/* Holo's live layer behind every screen, one shader for both modes and both
   backgrounds.

   Inputs from Nova: res, t, dark (1 in dark mode, 0 in light), scene (which
   background is chosen: 0 Prism Fold, 1 Cobalt Current), ptr (the pointer,
   0..1, eased), flow (the page's scroll, in screens, eased), and the pack's
   strength and speed.

   Cobalt Current, dark: a film of thin-film interference drifting over the
   chrome scene, laid over it with mix-blend-mode: overlay (skin.css), so mid
   grey changes nothing. The pointer and the scroll push the film along. In
   light mode the same film lies over the glass on silver (soft-light).

   Prism Fold, in either mode: liquid chrome, drawn here and not painted. A slowly flowing height
   field is lit by a studio (sky, horizon, soft boxes, a flag) and what each
   point reflects is what you see. The reflection never rests: it flows with
   time, slides when the page scrolls and swims when the pointer moves, and
   each colour is bent a little differently, so the edges split the way
   light does through a lens. The light's own surfaces (skin.css) catch the
   same light through --hx, --hy and --hf. */
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v;
uniform vec2 res;
uniform float t;
uniform float dark;
uniform float scene;
uniform vec2 ptr;
uniform float flow;
uniform float strength;
uniform float speed;

float h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3. - 2. * f);
  return mix(mix(h(i), h(i + vec2(1., 0.)), f.x), mix(h(i + vec2(0., 1.)), h(i + vec2(1., 1.)), f.x), f.y);
}

/* ---------- Cobalt Current: the film ---------- */
vec3 foil(vec2 p) {
  float s = mod(t, 2000.) * speed + flow * .35 + (ptr.x - .5) * .25;
  vec2 q = vec2(n(p * 1.2 + vec2(s, -s * .7)), n(p * 1.2 + vec2(5.2 - s * .6, 1.3 + s)));
  vec2 r = vec2(n(p * 1.9 + q * 2.2 + vec2(1.7, 9.2) + s * .8), n(p * 1.9 + q * 2.2 + vec2(8.3, 2.8) - s * .6));
  float film = n(p * 1.4 + r * 2.6);
  float d = film * 2.4 + (p.x - p.y) * .25 + s * .5;
  vec3 iri = .5 + .5 * cos(6.2832 * (d + vec3(0., .33, .67)));
  float band = smoothstep(.3, .95, n(p * 2.2 + r * 3. - s));
  return mix(vec3(.5), iri, strength * (.3 + .7 * band));
}

/* ---------- light: liquid chrome ---------- */
/* the surface: coordinates bent over and over, so ridges fold like poured metal */
float height(vec2 p, float s) {
  p += vec2(s * .6, -s * .35);
  for (int i = 1; i < 5; i++) {
    float fi = float(i);
    p += vec2(cos(p.y * fi * .8 + s * .9 + fi), sin(p.x * fi * .7 - s * .8 + fi * 1.7)) * .55 / fi;
  }
  return .55 * sin(p.x * 1.15 + p.y * .35) + .45 * cos(p.y * 1.05 - p.x * .3);
}

/* the studio a reflection ends up in: x is across, y is up */
vec3 studio(vec2 r) {
  float y = r.y;
  /* sky above, steel below, a crisp horizon between */
  vec3 col = mix(vec3(.55, .59, .67), vec3(.86, .89, .94), smoothstep(-.35, .75, y));
  col *= 1. - .6 * smoothstep(.08, .0, abs(y - .02 + .05 * sin(r.x * 2.)));
  /* a long soft box overhead, a tall one to the right, a thin strip to the left */
  col += .26 * smoothstep(.12, -.04, abs(r.x - .1) - .55) * smoothstep(.12, -.04, abs(y - .62) - .09);
  col += .24 * smoothstep(.08, -.03, abs(r.x - .62) - .07) * smoothstep(.1, -.04, abs(y - .12) - .5);
  col += .2 * smoothstep(.06, -.02, abs(r.x + .58) - .025) * smoothstep(.1, -.04, abs(y - .2) - .42);
  /* a flag: a dark panel the metal keeps catching */
  col *= 1. - .62 * smoothstep(.08, -.03, abs(r.x + .2) - .09) * smoothstep(.08, -.03, abs(y - .38) - .22);
  return col;
}

/* the same studio with the lights off: black glass, a few hard strips of
   white light, a horizon line. Neutral, so the black reads as black; the
   only colour is what the lens splits out of the edges. */
vec3 studioDark(vec2 r) {
  float y = r.y;
  vec3 col = vec3(.004) + vec3(.03) * smoothstep(-.4, .85, y);
  /* the thin lines carry the colour: a hue that travels along each one */
  vec3 hz = .5 + .5 * cos(6.2832 * (r.x * .32 + y * .2 + vec3(0., .33, .67)));
  col += mix(vec3(1.), hz, .55) * .8 * smoothstep(.06, .0, abs(y - .02 + .05 * sin(r.x * 2.)));
  col += vec3(1.) * smoothstep(.1, -.03, abs(r.x - .08) - .5) * smoothstep(.07, -.03, abs(y - .6) - .035);
  col += mix(vec3(1.), hz, .55) * 1.25 * smoothstep(.06, -.02, abs(r.x - .64) - .035) * smoothstep(.08, -.03, abs(y - .1) - .5);
  col += mix(vec3(1.), hz, .55) * .6 * smoothstep(.05, -.02, abs(r.x + .56) - .02) * smoothstep(.08, -.03, abs(y - .2) - .4);
  col += vec3(.3) * smoothstep(.2, -.05, abs(r.x + .05) - .3) * smoothstep(.2, -.05, abs(y + .42) - .06);
  return col;
}

vec3 chromeDark(vec2 p) {
  float s = mod(t, 3000.) * .07 + flow * .55;
  float e = .02;
  float c = height(p, s);
  float gx = height(p + vec2(e, 0.), s) - c;
  float gy = height(p + vec2(0., e), s) - c;
  vec3 nrm = normalize(vec3(-gx / e * .9, -gy / e * .9, 1.));
  vec2 r = nrm.xy * 2. * nrm.z;
  r += vec2((ptr.x - .5) * .7, (.5 - ptr.y) * .45) + vec2(0., flow * .3);
  /* black chrome splits harder: the colours part far enough to be seen */
  float d = .04 + .05 * length(nrm.xy);
  vec3 col = vec3(studioDark(r * (1. + d)).r, studioDark(r).g, studioDark(r * (1. - d)).b);
  vec3 iri = .5 + .5 * cos(6.2832 * (c * .7 + length(r) * .3 + vec3(0., .33, .67)));
  col = mix(col, col * (.5 + 1.1 * iri), .2);
  float chroma = max(col.r, max(col.g, col.b)) - min(col.r, min(col.g, col.b));
  float L = dot(col, vec3(.3333));
  col = mix(col, clamp(vec3(L) + (col - vec3(L)) * 1.5, 0., 1.), smoothstep(.02, .2, chroma));
  /* never pure black, never glaring: text sits on it */
  col = col / (1. + col * .4) * 1.2 + vec3(.004);
  return clamp(col, 0., 1.);
}

vec3 chrome(vec2 p) {
  float s = mod(t, 3000.) * .07 + flow * .55;
  float e = .02;
  float c = height(p, s);
  float gx = height(p + vec2(e, 0.), s) - c;
  float gy = height(p + vec2(0., e), s) - c;
  /* the slope, steep enough that the reflection travels far across the studio */
  vec3 nrm = normalize(vec3(-gx / e * .9, -gy / e * .9, 1.));
  vec2 r = nrm.xy * 2. * nrm.z;
  /* the viewpoint: the pointer moves it, the scroll tilts the panel */
  r += vec2((ptr.x - .5) * .7, (.5 - ptr.y) * .45) + vec2(0., flow * .3);
  /* dispersion: each colour reflects a little further out */
  float d = .02 + .07 * length(nrm.xy);
  vec3 col = vec3(studio(r * (1. + d)).r, studio(r).g, studio(r * (1. - d)).b);
  /* a faint film of colour on the metal, never a wash */
  vec3 iri = .5 + .5 * cos(6.2832 * (c * .6 + length(r) * .25 + vec3(0., .33, .67)));
  col = mix(col, col * (.7 + .6 * iri), .1);
  /* the lines: where the metal turns sharply the split colours are pushed
     to full strength, and the brightest light is held just under white */
  float L = dot(col, vec3(.3333));
  float edge = smoothstep(.07, .26, max(col.r, max(col.g, col.b)) - min(col.r, min(col.g, col.b)));
  col = mix(col, clamp(vec3(L) + (col - vec3(L)) * 2.4, 0., 1.), edge);
  col -= max(col - .86, 0.) * .55;
  /* lifted: this is a light skin, text sits on it */
  col = mix(col, vec3(.93, .95, .98), .1);
  return clamp(col, 0., 1.);
}

void main() {
  vec2 p = (v - .5) * vec2(res.x / res.y, 1.) * 2.;
  vec3 col;
  if (scene < .5) col = dark > .5 ? chromeDark(p * 1.15) : chrome(p * 1.15);  /* Prism Fold */
  else col = foil(p);                                                           /* Cobalt Current: only its film */
  gl_FragColor = vec4(col, 1.);
}
