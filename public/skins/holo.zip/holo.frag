/* Nova's mark as liquid holographic chrome on the startup screen.
   Inputs from Nova: tex (the logo), t (seconds), px (one texel).

   The flow is the iterated cosine warp of liquid-logo (Alan Ang, MIT, after
   XorDev's "Plasma"); the colour is thin-film interference, one phase per
   channel, so the bands run through the spectrum; the edge is split into
   red and blue, as a lens disperses light, breathing in and out. */
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v;
uniform sampler2D tex;
uniform float t;
uniform float px;
float m(vec2 p) { return texture2D(tex, clamp(p, 0., 1.)).a; }
void main() {
  /* the logo fills the middle 80% of the canvas, like holo-mark.svg */
  vec2 g = (vec2(v.x, 1. - v.y) - .1) / .8;
  float tt = mod(t, 600.);
  /* dispersion: each channel sees the logo a little further out */
  vec2 dir = (g - .5) * (.018 + .012 * sin(tt * 1.6));
  float aR = m(g + dir), aG = m(g), aB = m(g - dir);
  float a = max(aG, max(aR, aB));
  if (a < .004) { gl_FragColor = vec4(0.); return; }
  /* a bevel from the logo's own edges */
  float d = px * 5.;
  float dx = m(g + vec2(d, 0.)) - m(g - vec2(d, 0.));
  float dy = m(g + vec2(0., d)) - m(g - vec2(0., d));
  vec3 n = normalize(vec3(-dx, dy, .45));
  /* the liquid */
  vec2 p = g * 2.6;
  for (int i = 1; i < 5; i++) {
    float fi = float(i);
    p += vec2(cos(p.y * fi * .9 + tt * .55 + fi), sin(p.x * fi * .8 - tt * .45 + fi * 1.3)) * .38 / fi;
  }
  float film = p.x * .6 + p.y * .4 + n.x * 1.6 + n.y * 1.1 - tt * .3;
  vec3 iri = .5 + .5 * cos(6.2832 * (film * .42 + vec3(0., .33, .67)));
  /* black chrome under the film: petrol to ice, pinched at the bends */
  float band = smoothstep(-.35, .85, sin(film * 1.9));
  vec3 chrome = mix(vec3(.04, .1, .13), vec3(.8, .97, .95), band);
  vec3 col = mix(chrome, iri, .5);
  col += pow(max(0., dot(n, normalize(vec3(-.4, .6, .7)))), 26.) * 1.2;
  col += iri * (1. - n.z) * 1.4;
  /* a warm filament along the tightest bends */
  col += vec3(1., .78, .5) * pow(max(0., sin(film * 3.8 + 1.)), 18.) * .55;
  col = clamp(col, 0., 1.);
  gl_FragColor = vec4(col * vec3(aR, aG, aB), a);
}
