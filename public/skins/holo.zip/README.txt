HOLO, a skin for Nova
=====================

Nova in black chrome and prism light (dark mode) or liquid chrome (light
mode): liquid glass behind every screen
with its light splitting into colour, foil buttons, edges that fringe like
a lens, and a startup screen that projects the mark into the air.

Thank you for supporting Nova.

Needs Nova 1.3.1 or newer. An older version does not know Holo yet:
update Nova first.


HOW TO ADD IT
-------------

Do not unzip this file. Nova reads the .zip as it is.

On your phone (Android)
  1. Download the .zip. It goes to your Downloads folder.
  2. Open Nova, then Settings > Look.
  3. Under Skin, tap "Add skin from file".
  4. Pick the .zip from Downloads.
  5. Holo is switched on straight away. You can switch back to Nova's own
     look on the same screen at any time.

On your computer (Nova for Windows or Linux)
  1. Download the .zip.
  2. Open Nova, then Settings > Look.
  3. Under Skin, click "Add skin from file" and pick the .zip.

Nova keeps its own copy, so you can delete the download afterwards.

Two backgrounds come with it, Prism Fold (liquid chrome, live) and Cobalt
Current (glass): both work in dark and in light. Pick one in
Settings > Look > Background.


MOVING IT TO YOUR OTHER DEVICES
-------------------------------

- Sync with Nova Bridge (Settings > You > Sync) carries your skins to
  your other devices along with your library.
- A backup carries them too if "Include skins" is on in Settings > You >
  Backup.
- Or add this same .zip on each device.


UPDATES
-------

When there is a new version, download it again and add it the same way.
It replaces the old one.


WHAT A SKIN CAN DO
------------------

A Nova skin is pictures, fonts, a stylesheet and a few shaders. It changes
how Nova looks and moves and nothing else: it holds no code, cannot see
your chats or keys, and cannot go online.

Motion follows Settings > Look > Motion: Calm, Off and reduced motion show
one still frame.

The display typeface is Sora, under the SIL Open Font License
(fonts/OFL.txt).
